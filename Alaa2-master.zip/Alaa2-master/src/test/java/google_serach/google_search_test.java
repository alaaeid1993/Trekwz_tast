package google_serach;

import Search.google_search_page;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;
import java.util.concurrent.TimeUnit;


public class google_search_test {
    public static WebDriver driver;
    public static google_search_page p_search;

    @BeforeMethod
    public void testSetup()
    {
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.google.com/");
        p_search = new google_search_page(driver);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

    @AfterMethod
    public void afterMethod() throws InterruptedException {
        Thread.sleep(5000);
        driver.close();
    }

    @Test(priority = 0)
    public void search_001 () throws InterruptedException
    {
        p_search.type_text("selenium webdriver");

        List<WebElement> list = driver.findElements(By.xpath("//ul[@role='listbox']//li/descendant::div[@class='wM6W7d']"));
        for (int i = 0; i < list.size(); i++)
        {
            String items = list.get(2).getText();
            if (items.contains(""))
            {
                String ac = list.get(2).getText();
                String ex = "What is Selenium WebDriver";
                Assert.assertEquals(ac, ex,"The Third Result Not Contain 'What is Selenium WebDriver'");
                break;
            }
        }
    }
}