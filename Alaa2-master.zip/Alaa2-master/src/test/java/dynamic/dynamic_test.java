package dynamic;

import Dynanic.dynamic_page;
import Upload.upload_page;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class dynamic_test
{
    public static WebDriver driver;
    public static dynamic_page dy;

    @BeforeMethod
    public void testSetup() {
        WebDriverManager.edgedriver().setup();
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://the-internet.herokuapp.com");
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)");
        dy = new dynamic_page(driver);
        //dy.d_load();

    }

    @AfterMethod
    public void afterMethod() throws InterruptedException {
        Thread.sleep(1000);
        driver.close();
    }

    @Test(priority = 1)
    public void dyan ()throws InterruptedException
    {
        dy.all();
//        String mainWindowHandle = driver.getWindowHandle();
//        Set<String> allWindowHandles = driver.getWindowHandles();
//        Iterator<String> it = allWindowHandles.iterator();
//        String p1 = it.next();
//        String p2 = it.next();
//        driver.switchTo().window(p2);
//        Thread.sleep(1000);
//        dy.ex_but();
    }
}
