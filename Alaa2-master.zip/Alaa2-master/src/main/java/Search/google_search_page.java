package Search;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class google_search_page
{
    public static WebDriver driver;
    By search = By.name("q");

    public google_search_page(WebDriver driver) {
        this.driver = driver;
    }

    public  void type_text(String Text)
    {
        driver.findElement(search).sendKeys(Text);
    }


}
