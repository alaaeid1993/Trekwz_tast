package Dynanic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class dynamic_page
{
    public static WebDriver driver;

    By dynamic_but = By.linkText("Dynamic Loading");
    By ex_2 = By.id("Example 2: Element rendered after the fact");


    public dynamic_page(WebDriver driver)
    {
        this.driver = driver;
    }

    public  void d_load()
    {
        driver.findElement(dynamic_but).click();
    }

    public  void ex_but() {driver.findElement(ex_2).click();}

    public  void all()
    {
        d_load();
        driver.navigate().to("https://the-internet.herokuapp.com/dynamic_loading");
        ex_but();
    }
}
