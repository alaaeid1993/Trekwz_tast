package Upload;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class upload_page
{
    public static WebDriver driver;

    By upload_but = By.linkText("File Upload");
    By choose = By.id("file-upload");


    public upload_page(WebDriver driver)
    {
        this.driver = driver;
    }

    public  void u_file()
    {
        driver.findElement(upload_but).click();
    }

    public  void choose_but()
    {
        driver.findElement(choose).click();
    }

}
